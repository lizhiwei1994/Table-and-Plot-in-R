library(testthat)
library(vdiffr)
library(forestploter)

test_check("forestploter")
