
#' Deprecated functions in \code{arsenal}
#'
#' Details about deprecated functions in \code{arsenal}
#'
#' @seealso \code{\link{arsenal-defunct}}
#' @name arsenal-deprecated
NULL
#> NULL
