library(testthat)
library(gtsummary)

test_check("gtsummary")
options(usethis.quiet = TRUE)
