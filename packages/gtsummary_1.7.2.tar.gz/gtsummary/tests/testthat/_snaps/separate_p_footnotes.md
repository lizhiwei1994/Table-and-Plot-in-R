# no errors/warnings with standard use

    Code
      separate_p_footnotes(gts_tbl) %>% as.data.frame()
    Output
        **Characteristic** **Drug A**, N = 98 **Drug B**, N = 102 **p-value**
      1                Age        46 (37, 59)         48 (39, 56)         0.7
      2            Unknown                  7                   4        <NA>
      3              Grade               <NA>                <NA>         0.9
      4                  I           35 (36%)            33 (32%)        <NA>
      5                 II           32 (33%)            36 (35%)        <NA>
      6                III           31 (32%)            33 (32%)        <NA>

