# modify_column_indent() works

    Code
      tbl %>% as.data.frame()
    Output
        **Characteristic** **N = 200**
      1              Grade        <NA>
      2                  I    68 (34%)
      3                 II    68 (34%)
      4                III    64 (32%)

