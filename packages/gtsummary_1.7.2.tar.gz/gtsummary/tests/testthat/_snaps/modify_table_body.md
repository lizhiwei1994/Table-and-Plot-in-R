# modify_table_body with standard use

    Code
      t1 %>% as.data.frame()
    Output
          **Characteristic** **OR** **Control N** **Case N** **95% CI** **p-value**
      1                  Age   1.02           125       58.0 1.00, 1.04        0.10
      2 Marker Level (ng/mL)   1.35           126       57.0 0.94, 1.93        0.10

