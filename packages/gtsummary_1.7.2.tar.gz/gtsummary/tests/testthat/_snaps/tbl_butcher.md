# tbl_butcher() works

    Code
      tbl_sml %>% as.data.frame()
    Output
            **Characteristic**       **N = 200**
      1   Marker Level (ng/mL) 0.64 (0.22, 1.39)
      2                Unknown                10
      3 Chemotherapy Treatment              <NA>
      4                 Drug A          98 (49%)
      5                 Drug B         102 (51%)

